1. To execute this application please run DocumentGenerator.java as run as Java Application
   Or run AssignmentApplication.java as Spring Boot Application.
   
2. DocumentGenerator.java class contains the logic to generate the CVS and XML file.

3. The input file small.in is located in "src/main/resources" folder.

4. Once you run this application you will get the output.xml and output.csv file in same "src/main/resources" folder.

5. To read the large.in you need to modify filePath variable in the main method of DocumentGenerator.java

6. To run all the JUnit classes you can run the JUnit Suite AssignmentTestSuite.java.

7. To create XML file we have used DOM parser provided by JDK.

8. To create CSV file we have used openCSV.