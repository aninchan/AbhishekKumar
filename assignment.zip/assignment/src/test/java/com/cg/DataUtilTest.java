package com.cg;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.model.Sentence;
import com.cg.util.DataUtil;

/**
 * Test class to test all methods of DataUtil class.
 * 
 * @author abhaisha
 */
public class DataUtilTest {

	String[] sentences = null;
	String filePath = "src/main/resources/small.in";

	@BeforeEach
	void setUp() throws Exception {
		sentences = DataUtil.readFileSentences(filePath);
	}

	@Test
	void testReadFileSentences() {
		sentences = DataUtil.readFileSentences(filePath);
		Assertions.assertTrue(sentences.length > 0);
	}

	@Test
	void testGetCVSMap() {
		Map<Sentence, List<String[]>> csvMap = DataUtil.getLineMap(sentences);
		Assertions.assertTrue(csvMap.size() > 0);
	}

	@AfterEach
	void tearDown() throws Exception {
		sentences = null;
	}

}
