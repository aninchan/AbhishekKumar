package com.cg;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.model.Sentence;
import com.cg.service.DocumentGenerator;
import com.cg.util.DataUtil;

/**
 * Test class to test methods of DocumentGenerator class.
 * 
 * @author abhaisha
 */
public class DocumentGeneratorTest {

	String[] sentences;
	DocumentGenerator documentGenerator;
	Map<Sentence, List<String[]>> dataMap;
	String filePath = "src/main/resources/small.in";

	@BeforeEach
	void setUp() throws Exception {
		documentGenerator = new DocumentGenerator();
		sentences = DataUtil.readFileSentences(filePath);
		dataMap = DataUtil.getLineMap(sentences);
	}

	@Test
	void testCreateCSV() {
		Assertions.assertTrue(documentGenerator.createCSV(dataMap));
	}

	@Test
	void testCreateXML() {
		Assertions.assertTrue(documentGenerator.createXML(dataMap));
	}

	@AfterEach
	void tearDown() throws Exception {
		documentGenerator = null;
		sentences = null;
		dataMap = null;
	}

}
