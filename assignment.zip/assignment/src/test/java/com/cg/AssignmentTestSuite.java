package com.cg;

import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.SelectClasses;
import org.junit.runner.RunWith;

/**
 * Test suite to run all test classes.
 * 
 * @author abhaisha
 */
@RunWith(JUnitPlatform.class)
@SelectClasses({ DataUtilTest.class, DocumentGeneratorTest.class })
public class AssignmentTestSuite {

}
