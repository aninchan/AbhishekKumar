package com.cg.util;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cg.model.Sentence;
import com.cg.service.DocumentGenerator;

/**
 * The Utility class which provide the general methods which may used in many
 * classes.
 * 
 * @author abhaisha
 */
public class DataUtil {
	
	static Logger log = LoggerFactory.getLogger(DocumentGenerator.class);

	/**
	 * Method to read txt file
	 * 
	 * @return sentences as String array.
	 */
	public static String[] readFileSentences(String filePath) {

		String[] sentences = null;
		try {
			String content = readFile(filePath, StandardCharsets.UTF_8);
			// Spliting the sentences in the file by dot or exclamation or question mark.
			sentences = content.split("\\.|!|\\?");
		} catch (IOException e) {
			log.error(e.getMessage());
		}
		return sentences;
	}

	/**
	 * Method to generate the map from the sentence.
	 * 
	 * @param sentences contains the String array of sentences.
	 * @return map contains the sentence as key and words as value.
	 */
	public static Map<Sentence, List<String[]>> getLineMap(String[] sentences) {
		int count = 1;
		List<String[]> sentenceWords = null;
		Map<Sentence, List<String[]>> cvsMap = new LinkedHashMap<>();
		for (String sentence : sentences) {

			String[] words = removeExtraSpaces(sentence.split("\\s|,"));
			// continue the iteration if line does not contain any word.
			if ((null == words) || (words.length == 0)) {
				continue;
			}

			// Sorting words from sentence by ascending order using Comparator interface
			Arrays.sort(words, new Comparator<String>() {
				@Override
				public int compare(String string1, String string2) {
					return string1.toLowerCase().compareTo(string2.toLowerCase());
				}
			});
			String[] labelWords = new String[words.length + 1];
			sentenceWords = new ArrayList<>();
			labelWords[0] = "sentence " + count;
			System.arraycopy(words, 0, labelWords, 1, words.length);

			sentenceWords.add(labelWords);
			count++;
			cvsMap.put(new Sentence("sentence"), sentenceWords);
		}
		return cvsMap;
	}

	/**
	 * Method to read the file
	 * 
	 * @param filePath is the file with location.
	 * @param encoding is the encoding method.
	 * @return File content as String.
	 * @throws IOException
	 */
	private static String readFile(String filePath, Charset encoding) throws IOException {
		byte[] encoded = Files.readAllBytes(Paths.get(filePath));
		return new String(encoded, encoding);
	}

	//
	/**
	 * Method to remove empty string from array
	 * 
	 * @param words as the array of String.
	 * @return array of String.
	 */
	public static String[] removeExtraSpaces(String[] words) {
		return Arrays.stream(words).filter(x -> !x.isEmpty()).toArray(String[]::new);
	}

}
