package com.cg.model;

/**
 * Sentence is a model class contains the value as String.
 * 
 * @author abhaisha
 */
public class Sentence {

	String value;

	public Sentence(String value) {
		super();
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
