package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cg.service.DocumentGenerator;

/**
 * Main Spring Boot application class.
 * 
 * @author abhaisha
 *
 */
@SpringBootApplication
public class AssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssignmentApplication.class, args);
		DocumentGenerator.main(null);
	}

}
