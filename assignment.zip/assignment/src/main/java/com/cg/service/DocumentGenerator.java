package com.cg.service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.cg.model.Sentence;
import com.cg.util.DataUtil;
import com.opencsv.CSVWriter;

/**
 * The DocumentGenerataor class contains the logic to generate the CSV and XML
 * file. It is the main class of the application.
 * 
 * @author abhaisha
 */
@Service
public class DocumentGenerator {
	
	static Logger log = LoggerFactory.getLogger(DocumentGenerator.class);

	public static void main(String[] args) {

		DocumentGenerator documentGenerator = new DocumentGenerator();

		// File path of input file
		String filePath = "src/main/resources/small.in";
		
		log.info("File read start");
		String[] sentences = DataUtil.readFileSentences(filePath);
		log.info("File read end");

		// Generate the map
		Map<Sentence, List<String[]>> map = DataUtil.getLineMap(sentences);

		log.info("CSV create start");
		documentGenerator.createCSV(map);
		log.info("CSV create end");

		log.info("XML create start");
		documentGenerator.createXML(map);
		log.info("XML create end");
	}

	/**
	 * Method to generate output CSV file and Store words for each sentence as per
	 * requirement
	 * 
	 * @param map contains the sentence as key and list of words array as value
	 * @return true if CSV created without any error.
	 */
	public boolean createCSV(Map<Sentence, List<String[]>> map) {

		int wordCount = 0;
		// count the max lenght of the number of words in a sentence among all
		// sentences.
		for (List<String[]> list : map.values()) {
			if (list.get(0).length > wordCount) {
				wordCount = list.get(0).length;
			}
		}

		try {
			// write the content to output.csv
			CSVWriter csvWrite = new CSVWriter(new FileWriter("src/main/resources/output.csv"));
			String[] entries = new String[wordCount];
			entries[0] = "";
			for (int i = 1; i < wordCount; i++) {
				entries[i] = "Word " + i;
			}
			csvWrite.writeNext(entries);
			map.forEach((k, v) -> csvWrite.writeAll(v));
			csvWrite.close();
			return true;

		} catch (IOException e) {
			log.error(e.getMessage());
		}
		return false;
	}

	/**
	 * Method to generate output xml file and Store words for each sentence as per
	 * requirement
	 * 
	 * @param map contains the sentence as key and list of words array as value
	 * @return true if xml created without any error.
	 */
	public boolean createXML(Map<Sentence, List<String[]>> map) {
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();

			// text root element
			Element rootElement = doc.createElement("texts");
			doc.appendChild(rootElement);
			map.forEach((key, value) -> {
				Element sentence = doc.createElement(key.getValue());
				value.forEach(words -> {
					for (String word : words) {
						if (word.startsWith("sentence ") && word.matches("^.*\\d$"))
							continue;
						Element wordName = doc.createElement("word");
						wordName.setTextContent(word);
						sentence.appendChild(wordName);
					}
				});
				rootElement.appendChild(sentence);
			});

			// Write the content into XML file
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("src/main/resources/output.xml"));

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();

			// Beautify the format of the resulted XML
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			transformer.transform(source, result);
			
			return true;
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return false;
	}

}
